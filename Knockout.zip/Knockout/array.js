var employees;

var empViewModel = {
	'firstName':{
		'create':function(options){
			return ko.observable(options.data.toUpperCase());
		}
	}
};

function ArrayViewModel() {
    response = {
   'employees':[{
      "employee":{
         "personId":1223,
         "firstName":"Marco",
         "lastName":"Franssen",
         "age":26,
         "webpage":"http://marcofranssen.nl",
         "twitter":"@marcofranssen"
      }},
      {"employee":{
         "personId":1,
         "firstName":"Thierry",
         "lastName":"Breton",
         "age":null,
         "webpage":"",
         "twitter":""
      }},
      {"employee":{
         "personId":1233213,
         "firstName":"John",
         "lastName":"Doe",
         "age":33,
         "webpage":"http://john.doe",
         "twitter":"@johndoe"
      }}
   ]};
   this.employees = ko.mapping.fromJS(response.employees,empViewModel);
}

ko.applyBindings(new ArrayViewModel());