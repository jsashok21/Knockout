var company;

function PersonViewModel(data) {
    var personMapping = {
        'ignore': ['twitter', 'webpage'],
        'copy': ['age'],
        'lastName': {
            'create': function(options) {
                return ko.observable(options.data.toUpperCase());
            }
        }
    };

    ko.mapping.fromJS(data, personMapping, this);

    this.fullName = ko.computed(function() {
        return this.firstName() + ' ' + this.lastName();
    }, this);
}

function CompanyViewModel(data) {
    var companyMapping = {
        'ignore': ['address', 'website'],
        'name': {
            'create': function(options) {
                return ko.observable(options.data.toUpperCase());
            }
        },
        'employees': {
            key: function(data) {
                return ko.utils.unwrapObservable(data.personId);
            },
            create: function(options) {
                return new PersonViewModel(options.data);
            }
        }
    };

    ko.mapping.fromJS(data, companyMapping, this);
}
var employees;
var empViewModel = function(data){
    var empMapping = {
        'firstName':{
            'create':function(options){
                return ko.observable(options.data.toUpperCase());
            }
        }
    };
    ko.mapping.fromJS(data, empMapping, this);
}
var AppViewModel = function(data){
    //employees = ko.observableArray();
    var splMapping = {
        'employees' : {
            'create':function(options){
                return new empViewModel(options.data);
            }
        }
    };
    ko.mapping.fromJS(data,splMapping,this);
}

function myFun(){
    response = {
   'employees':[{
      "employee":{
         "personId":1223,
         "firstName":"Marco",
         "lastName":"Franssen",
         "age":26,
         "webpage":"http://marcofranssen.nl",
         "twitter":"@marcofranssen"
      }},
      {"employee":{
         "personId":1,
         "firstName":"Thierry",
         "lastName":"Breton",
         "age":null,
         "webpage":"",
         "twitter":""
      }},
      {"employee":{
         "personId":1233213,
         "firstName":"John",
         "lastName":"Doe",
         "age":33,
         "webpage":"http://john.doe",
         "twitter":"@johndoe"
      }}
   ]};
    //company = new CompanyViewModel(response);
    //employees = ko.mapping.fromJS(response,AppViewModel);
    employees = new AppViewModel(response);
    ko.applyBindings(employees, $('#empTable').get(0));
}
myFun();